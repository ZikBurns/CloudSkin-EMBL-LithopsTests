from .aws_ec2 import AWSEC2Backend as StandaloneBackend

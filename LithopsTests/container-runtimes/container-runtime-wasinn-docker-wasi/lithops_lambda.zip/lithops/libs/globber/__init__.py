from .globber import match

name = 'globber'